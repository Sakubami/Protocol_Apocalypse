package xyz.sakubami.protocol_apocalypse.shared.network.client.gamestate;

import xyz.sakubami.protocol_apocalypse.server.logic.chunks.Chunk;
import xyz.sakubami.protocol_apocalypse.server.logic.objects.GameObject;
import xyz.sakubami.protocol_apocalypse.server.saving.data.ChunkBatch;
import xyz.sakubami.protocol_apocalypse.server.saving.data.SerializedChunk;
import xyz.sakubami.protocol_apocalypse.shared.types.TileType;
import xyz.sakubami.protocol_apocalypse.shared.utils.Vector2f;
import xyz.sakubami.protocol_apocalypse.shared.utils.Vector2i;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChunkState {
    public boolean remove = false;
    public TileType[] tiles;
    public final Map<Vector2f, ObjectState> objects = new HashMap<>();

    public ChunkState(Chunk chunk) {
        this.tiles = chunk.getTiles();
        for (Map.Entry<Vector2f, GameObject> entry : chunk.getObjects().entrySet()) {
            this.objects.put(entry.getKey(), new ObjectState(entry.getValue()));
        }
    }

    public ChunkState(Chunk chunk, boolean remove) {
        this.tiles = chunk.getTiles();
        this.remove = remove;
        for (Map.Entry<Vector2f, GameObject> entry : chunk.getObjects().entrySet()) {
            this.objects.put(entry.getKey(), new ObjectState(entry.getValue(), remove));
        }
    }

    public ChunkState(boolean remove) {
        this.remove = remove;
    }

    public void write(DataOutputStream out) throws IOException {
        // Entities
        out.writeInt(tiles.length);
        for (TileType tile : tiles) {
            out.writeInt(tile.getId());
        }

        // Chunks
        out.writeInt(objects.size());
        for (Map.Entry<Vector2f, ObjectState> entry : objects.entrySet()) {
            out.writeFloat(entry.getKey().x());
            out.writeFloat(entry.getKey().y());
            entry.getValue().write(out);
        }
    }

    public static ChunkState read(DataInputStream in) throws IOException {
        ChunkState state = new ChunkState(false);

        // Entities
        int tileCount = in.readInt();
        state.tiles = new TileType[tileCount];
        for (int i = 0; i < tileCount; i++) {
            state.tiles[i] = TileType.getByID(in.readInt());
        }

        // Chunks
        int objectCount = in.readInt();
        for (int i = 0; i < objectCount; i++) {
            ObjectState object = ObjectState.read(in);
            state.objects.put(object.pos, object);
        }

        return state;
    }

    public void addObject(ObjectState object) {
        this.objects.put(object.pos, object);
    }
    public TileType[] getTiles() { return tiles; }
    public ObjectState getObjectAt(Vector2f pos) { return this.objects.get(pos); }
}
