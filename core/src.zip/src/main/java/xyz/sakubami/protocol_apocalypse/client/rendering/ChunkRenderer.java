package xyz.sakubami.protocol_apocalypse.client.rendering;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import xyz.sakubami.protocol_apocalypse.client.logic.ClientWorld;
import xyz.sakubami.protocol_apocalypse.server.logic.objects.GameObject;
import xyz.sakubami.protocol_apocalypse.client.rendering.textures.TextureManager;
import xyz.sakubami.protocol_apocalypse.shared.Configuration;
import xyz.sakubami.protocol_apocalypse.shared.network.client.gamestate.ChunkState;
import xyz.sakubami.protocol_apocalypse.shared.network.client.gamestate.ObjectState;
import xyz.sakubami.protocol_apocalypse.shared.types.TileType;
import xyz.sakubami.protocol_apocalypse.shared.utils.Vector2f;
import xyz.sakubami.protocol_apocalypse.shared.utils.Vector2i;
import xyz.sakubami.protocol_apocalypse.server.logic.chunks.Chunk;
import xyz.sakubami.protocol_apocalypse.server.logic.chunks.ChunkManager;

@Deprecated
public record ChunkRenderer(SpriteBatch batch, ClientWorld clientWorld, int tileSize) {

    public void render() {
        for (Vector2f pos : clientWorld.getChunks().keySet()) {
            renderChunk(pos);
        }
    }

    private void renderChunk(Vector2f pos) {
        ChunkState chunk = clientWorld.getChunks().get(pos);
        int size = Configuration.getDefaultChunkSize();

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                TileType tile = chunk.getTiles()[x + y * size];

                float worldX = (pos.x() * size + x) * tileSize;
                float worldY = (pos.y() * size + y) * tileSize;

                batch.draw(TextureManager.get().getTileTexture(tile), worldX, worldY);
                ObjectState object = chunk.getObjectAt(new Vector2f(x, y));
                if (object != null)
                    batch.draw(TextureManager.get().getObjectTexture(object.getType()), worldX, worldY);
            }
        }
    }

    public void dispose() {
        batch.dispose();
    }
}
