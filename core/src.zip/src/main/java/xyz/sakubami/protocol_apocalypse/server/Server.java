package xyz.sakubami.protocol_apocalypse.server;

import xyz.sakubami.protocol_apocalypse.server.logic.world.World;
import xyz.sakubami.protocol_apocalypse.server.logic.world.entities.livingentity.Player;
import xyz.sakubami.protocol_apocalypse.server.saving.Saviour;
import xyz.sakubami.protocol_apocalypse.server.logic.world.WorldManager;
import xyz.sakubami.protocol_apocalypse.shared.network.Connection;
import xyz.sakubami.protocol_apocalypse.shared.network.Packet;
import xyz.sakubami.protocol_apocalypse.shared.network.ProxySession;
import xyz.sakubami.protocol_apocalypse.shared.network.client.gamestate.EntityState;
import xyz.sakubami.protocol_apocalypse.shared.network.client.gamestate.GameStateBuilder;
import xyz.sakubami.protocol_apocalypse.shared.network.packets.handlers.ServerPacketHandler;
import xyz.sakubami.protocol_apocalypse.shared.utils.Vector2f;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class Server {
    private final List<Connection> clients = new CopyOnWriteArrayList<>();
    private ServerSocket serverSocket;
    private volatile boolean running = false;
    private final ServerPacketHandler handler = new ServerPacketHandler(this);
    private World world;
    private Saviour saviour;

    private final Queue<Player> pendingPlayers = new LinkedList<>();
    private final Map<Connection, Player> connectedPlayers = new HashMap<>();
    private final Map<UUID, Player> onlinePlayers = new HashMap<>();
    private final Map<UUID, Player> offlinePlayers = new HashMap<>();

    public Server() {}

    public void start(int port) throws IOException {
        running = true;
        serverSocket = new ServerSocket(port);
        setupWorld("BITCH");
        System.out.println("Server started on port " + port);

        new Thread(() -> {
            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    Connection connection = new Connection(clientSocket, true);
                    clients.add(connection);
                    System.out.println("clients online currently: " + clients.size());
                    System.out.println("Client connected: " + clientSocket.getInetAddress());
                } catch (IOException e) {
                    if(running) e.printStackTrace();
                }
            }
        }).start();

        new Thread(() -> {
            while (running) {
                tick();
                try {
                    Thread.sleep(33); // ~30 ticks per second
                } catch (InterruptedException ignored) {
                }
            }
        }).start();
    }

    private void tick() {
        for (Connection c : clients) {
            if (!c.isAlive()) {
                disconnectClient(c);
                continue;
            }
            c.tick(handler); // read & execute packets
            System.out.println("server");
        }

        if (onlinePlayers.isEmpty())
            return;
        Player player = onlinePlayers.values().stream().filter(p -> p.getName().equals("sakubami")).findFirst().get();
        Vector2f move = new Vector2f(20, 0);
        player.setPos(player.getPos().add(move));
        System.out.println("x: " + player.getTilePos().x() + " y: " + player.getTilePos().y());

        GameStateBuilder stateBuilder = new GameStateBuilder();

        if (!pendingPlayers.isEmpty())
            stateBuilder.updateEntity(new EntityState(pendingPlayers.poll()));
        broadcast(world.tick(onlinePlayers.values(), stateBuilder).compile());
        saviour.tick();
    }

    private void disconnectClient(Connection c) {
        c.disconnect();
        System.out.println("DISCONNECTED CLIENT!!!");
    }

    public void setupWorld(String name) {
        this.world = WorldManager.get().selectWorld(name);
        this.saviour = new Saviour(world.getDirectory());
    }

    public void broadcast(Packet packet) {
        for (Connection c : clients) {
            c.send(packet);
        }
    }

    public void stop() throws IOException {
        WorldManager.get().saveWorld(world);

        this.running = false;
        serverSocket.close();
        for (Connection c : clients) {
            c.disconnect();
        }
    }

    public World getWorld() { return world; }
    public Map<UUID, Player> getOnlinePlayers() { return this.onlinePlayers; }
    public Map<UUID, Player> getOfflinePlayers() { return this.offlinePlayers; }
    public void updatePlayer(Player player) { this.onlinePlayers.replace(player.getUuid(), player); }
    public void connectPlayer(Connection adress, Player player) {
        this.onlinePlayers.put(player.getUuid(), player);
        this.connectedPlayers.put(this.clients.stream().filter(c -> c.getUUID().equals(adress.getUUID())).findFirst().get(), player);
        this.pendingPlayers.add(player);
    }
    public void disconnectPlayer(UUID uuid) { this.onlinePlayers.remove(uuid); }
    public Player getOnlinePlayer(UUID uuid) { return this.onlinePlayers.get(uuid); }
    public Player getOfflinePlayer(UUID uuid) { return this.offlinePlayers.get(uuid); }
}
